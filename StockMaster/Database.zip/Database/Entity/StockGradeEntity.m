//
//  StockGradeEntity.m
//  StockMaster
//
//  Created by Johnny on 15/5/25.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "StockGradeEntity.h"
#import "StockInfoEntity.h"


@implementation StockGradeEntity

@dynamic grade;
@dynamic quality;
@dynamic tendency;
@dynamic suggest;
@dynamic stockInfo;

@end
