//
//  SelectStockEntity.m
//  StockMaster
//
//  Created by Johnny on 15/4/10.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "SelectStockEntity.h"
#import "StockInfoEntity.h"


@implementation SelectStockEntity

@dynamic uid;
@dynamic profitRate;
@dynamic profitAmount;
@dynamic currentPrice;
@dynamic isPortfolio;
@dynamic isBuyable;
@dynamic status;
@dynamic buyMessage;
@dynamic createTime;
@dynamic updateTime;
@dynamic stockInfo;

@end
