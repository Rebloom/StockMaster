//
//  StockPlateEntity.m
//  StockMaster
//
//  Created by Johnny on 15/5/24.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "StockPlateEntity.h"
#import "PlateInfoEntity.h"
#import "StockInfoEntity.h"

@implementation StockPlateEntity

@dynamic updateTime;
@dynamic plateInfo;
@dynamic stockInfo;

@end
