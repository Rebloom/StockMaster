//
//  UserAssetEntity.m
//  StockMaster
//
//  Created by Johnny on 15/6/1.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "UserAssetEntity.h"


@implementation UserAssetEntity

@dynamic uid;
@dynamic totalAsset;
@dynamic initbaseMoney;
@dynamic usableMoney;
@dynamic profitMoney;
@dynamic positionMoney;
@dynamic withdrawMoney;

@end
