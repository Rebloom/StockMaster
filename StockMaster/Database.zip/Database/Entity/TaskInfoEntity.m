//
//  TaskInfoEntity.m
//  StockMaster
//
//  Created by Johnny on 15/4/17.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "TaskInfoEntity.h"


@implementation TaskInfoEntity

@dynamic uid;
@dynamic taskID;
@dynamic logID;
@dynamic name;
@dynamic describe;
@dynamic money;
@dynamic buttonText;
@dynamic status;
@dynamic taskIcon;
@dynamic h5Url;
@dynamic h5Title;
@dynamic h5Task;
@dynamic updateTime;

@end
