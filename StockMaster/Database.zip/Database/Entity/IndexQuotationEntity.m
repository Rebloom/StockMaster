//
//  IndexQuotationEntity.m
//  StockMaster
//
//  Created by Johnny on 15/4/21.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "IndexQuotationEntity.h"


@implementation IndexQuotationEntity

@dynamic code;
@dynamic name;
@dynamic exchange;
@dynamic currentPrice;
@dynamic updown;
@dynamic updownPrice;
@dynamic updownRange;
@dynamic updateTime;

@end
