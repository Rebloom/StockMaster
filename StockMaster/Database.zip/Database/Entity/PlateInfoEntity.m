//
//  PlateInfoEntity.m
//  StockMaster
//
//  Created by Johnny on 15/4/10.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "PlateInfoEntity.h"


@implementation PlateInfoEntity

@dynamic code;
@dynamic name;
@dynamic stockNum;
@dynamic updownRange;
@dynamic updateTime;

@end
