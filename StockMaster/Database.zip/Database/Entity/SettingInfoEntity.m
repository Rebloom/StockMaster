//
//  SettingInfoEntity.m
//  StockMaster
//
//  Created by Johnny on 15/4/17.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "SettingInfoEntity.h"


@implementation SettingInfoEntity

@dynamic uid;
@dynamic key;
@dynamic data;
@dynamic type;

@end
