//
//  MinuteLineEntity.m
//  StockMaster
//
//  Created by Johnny on 15/4/10.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "MinuteLineEntity.h"
#import "StockInfoEntity.h"

@implementation MinuteLineEntity

@dynamic time;
@dynamic price;
@dynamic updownRange;
@dynamic volume;
@dynamic avgPrice;
@dynamic allVolume;
@dynamic updown;
@dynamic stockInfo;

@end
