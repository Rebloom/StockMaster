//
//  VersionInfoEntity.m
//  StockMaster
//
//  Created by Johnny on 15/4/10.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "VersionInfoEntity.h"


@implementation VersionInfoEntity

@dynamic stockInfoVersion;

@end
