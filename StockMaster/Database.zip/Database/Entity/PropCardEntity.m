//
//  PropCardEntity.m
//  StockMaster
//
//  Created by Johnny on 15/7/13.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "PropCardEntity.h"


@implementation PropCardEntity

@dynamic uid;
@dynamic cardID;
@dynamic name;
@dynamic num;
@dynamic image;
@dynamic desc;
@dynamic status;
@dynamic buttonDesc;
@dynamic isDuration;
@dynamic expireTime;
@dynamic isSystemGive;
@dynamic systemGiveDesc;
@dynamic buyDesc;
@dynamic oldPrice;
@dynamic currentPrice;
@dynamic updateTime;

@end
