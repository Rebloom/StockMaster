//
//  UserInfoEntity.m
//  StockMaster
//
//  Created by Johnny on 15/4/23.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "UserInfoEntity.h"


@implementation UserInfoEntity

@dynamic uid;
@dynamic head;
@dynamic mobile;
@dynamic nickname;
@dynamic signature;
@dynamic token;
@dynamic updateTime;

@end
