//
//  SearchHistoryEntity.m
//  StockMaster
//
//  Created by Johnny on 15/4/22.
//  Copyright (c) 2015年 aizhangzhang. All rights reserved.
//

#import "SearchHistoryEntity.h"
#import "StockInfoEntity.h"


@implementation SearchHistoryEntity

@dynamic updateTime;
@dynamic stockInfo;

@end
